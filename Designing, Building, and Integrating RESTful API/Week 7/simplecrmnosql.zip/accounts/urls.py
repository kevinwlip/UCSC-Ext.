from django.conf.urls import url
from accounts.views import AccountCollection


urlpatterns = [
    url(
        r'^accounts$',
        AccountCollection.as_view()
    )
]