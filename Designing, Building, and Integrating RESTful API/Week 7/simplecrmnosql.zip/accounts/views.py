from rest_framework import permissions
from rest_framework_mongoengine import generics
from accounts.models import Account
from accounts.serializers import AccountSerializer


class AccountCollection(generics.ListCreateAPIView):
    serializer_class = AccountSerializer

    permission_classes = [
        permissions.IsAuthenticated
    ]

    def get_queryset(self):
        return Account.objects.filter(
            owner=self.request.user.username
        )

    def post(self, request, *args, **kwargs):
        request.data['owner'] = self.request.user.username
        return self.create(request)

