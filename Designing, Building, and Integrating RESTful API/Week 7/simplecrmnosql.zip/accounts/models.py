from mongoengine import Document, EmbeddedDocument, fields


class Contact(EmbeddedDocument):
    name = fields.StringField(required=True)
    phone = fields.StringField()


class Account(Document):
    owner = fields.StringField(required=True)
    name = fields.StringField(required=True)
    industry = fields.StringField(required=True)

    contacts = fields.ListField(fields.EmbeddedDocumentField(Contact))
