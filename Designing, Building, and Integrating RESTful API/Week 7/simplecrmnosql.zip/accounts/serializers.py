from rest_framework_mongoengine import serializers
from accounts.models import Account


class AccountSerializer(serializers.DocumentSerializer):
    class Meta:
        model = Account
        fields = '__all__'
