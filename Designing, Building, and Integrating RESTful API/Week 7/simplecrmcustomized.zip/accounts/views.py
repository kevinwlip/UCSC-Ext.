from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from rest_framework import status
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from accounts.models import Account
from accounts.serializers import AccountSerializer


class JSONResponse(HttpResponse):
    def __init__(self, data, **headers):
        content = JSONRenderer().render(data)
        headers['content_type'] = 'application/json'
        super(JSONResponse, self).__init__(content, **headers)


@csrf_exempt
def account_list(request):
    if request.method == 'GET':
        accounts = Account.objects.all()
        account_serializer = AccountSerializer(accounts, many=True)
        return JSONResponse(account_serializer.data)
    elif request.method == 'POST':
        account_data = JSONParser().parse(request)
        if type(account_data) is list:
            account_serializer = AccountSerializer(data=account_data, many=True)
        else:
            account_serializer = AccountSerializer(data=account_data)

        if account_serializer.is_valid():
            account_serializer.save()
            return JSONResponse(
                account_serializer.data,
                status=status.HTTP_201_CREATED
            )
        else:
            return JSONResponse(
                account_serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )
    elif request.method == 'PUT':
        account_data = JSONParser().parse(request)
        result = []
        errors = []
        try:
            for account in account_data:
                existing = Account.objects.get(pk=account['id'])
                account_serializer = AccountSerializer(
                    existing, data=account
                )
                if account_serializer.is_valid():
                    account_serializer.save()
                    result.append(account_serializer.data)
                else:
                    errors.append(account_serializer.errors)

            if len(result) == 0:
                return JSONResponse(errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return JSONResponse(result, status=status.HTTP_200_OK)
        except Exception as e:
            return JSONResponse(
                e,
                status=status.HTTP_400_BAD_REQUEST
            )