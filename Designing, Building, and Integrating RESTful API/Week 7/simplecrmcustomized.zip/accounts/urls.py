from django.conf.urls import url
from accounts.views import account_list


urlpatterns = [
    url(
        r'^accounts$',
        account_list
    )
]