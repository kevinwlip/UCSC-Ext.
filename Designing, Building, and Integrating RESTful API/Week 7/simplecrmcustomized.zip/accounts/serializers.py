from rest_framework import serializers
from accounts.models import Account, Contact


class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = ['id', 'name', 'phone']
        read_only_field = ('account',)


class AccountSerializer(serializers.ModelSerializer):
    contacts = ContactSerializer(many=True)

    class Meta:
        model = Account
        fields = '__all__'

    def create(self, validated_data):
        # remove contacts from the account data
        # create contact record one by one using the account data
        contacts = []
        if 'contacts' in validated_data:
            contacts = validated_data.pop('contacts')
        account = Account.objects.create(**validated_data)
        for contact in contacts:
            contact_serializer = ContactSerializer(data=contact)
            if contact_serializer.is_valid():
                contact_serializer.save(account=account)
        return account

    def update(self, instance, validated_data):
        instance.name = validated_data['name']
        instance.industry = validated_data['industry']
        contacts = []
        if 'contacts' in validated_data:
            contacts = validated_data.pop('contacts')
        for contact in contacts:
            contact_serializer = ContactSerializer(data=contact)
            if contact_serializer.is_valid():
                contact_serializer.save(account=instance)
        instance.save()
        return instance
