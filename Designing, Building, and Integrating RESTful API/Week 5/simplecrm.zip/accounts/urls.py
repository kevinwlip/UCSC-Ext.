from django.conf.urls import url
from accounts.views import AccountCollection, AccountItem, ContactCollection, ContactItem


urlpatterns = [
    url(
        r'accounts$',
        AccountCollection.as_view()
    ),
    url(
        r'accounts/(?P<pk>[0-9]+)$',
        AccountItem.as_view()
    ),
    url(
        r'contacts$',
        ContactCollection.as_view()
    ),
    url(
        r'contacts/(?P<pk>[0-9]+)$',
        ContactItem.as_view()
    )
]
