$(document).ready(
    () => {
        const user = {};

        $('#login-btn').click(
            () => {
                const username = $('#username').val();
                const password = $('#password').val();

                $.post(
                    'http://127.0.0.1:8000/rest-auth/login/',
                    {
                        username: username,
                        password: password
                    },
                    (response) => {
                        user.token = response.key;
                    }
                )
            }
        )
    }
)