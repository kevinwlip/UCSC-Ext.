from django.conf.urls import url, include
from django.urls import path
from rest_framework_jwt.views import obtain_jwt_token
from accounts.web_views import index

urlpatterns = [
    url(
        r'^api/',
        include('accounts.urls')
    ),
    url(
        r'^jwt-token$',
        obtain_jwt_token
    ),
    url(
        r'^rest-auth/',
        include('rest_auth.urls')
    ),
    url(
        r'^rest-auth/registration/',
        include('rest_auth.registration.urls')
    ),
    path('', index)
]
