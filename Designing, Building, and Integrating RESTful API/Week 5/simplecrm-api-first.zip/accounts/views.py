from rest_framework import generics, permissions
from django.core import exceptions
from accounts.models import Account, Contact
from accounts.serializers import AccountSerializer, ContactSerializer
from accounts.utils import custom_permissions


class AccountCollection(generics.ListCreateAPIView):
    serializer_class = AccountSerializer

    permission_classes = [
        permissions.IsAuthenticated
    ]

    def get_queryset(self):
        return Account.objects.filter(
            owner=self.request.user
        )

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class AccountItem(generics.RetrieveUpdateDestroyAPIView):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer

    permission_classes = [
        permissions.IsAuthenticatedOrReadOnly,
        custom_permissions.IsOwnerOrReadOnly
    ]


class ContactCollection(generics.CreateAPIView):
    queryset = Contact.objects.all()
    serializer_class = ContactSerializer

    permission_classes = [
        permissions.IsAuthenticated,
        custom_permissions.IsAccountOwner
    ]

    def perform_create(self, serializer):
        if serializer.validated_data['account'].owner != self.request.user:
            raise exceptions.PermissionDenied
        else:
            serializer.save()


class ContactItem(generics.RetrieveUpdateDestroyAPIView):
    queryset = Contact.objects.all()
    serializer_class = ContactSerializer

    permission_classes = [
        permissions.IsAuthenticated,
        custom_permissions.IsAccountOwner
    ]
