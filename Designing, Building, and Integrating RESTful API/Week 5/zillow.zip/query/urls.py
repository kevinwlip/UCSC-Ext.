from django.conf.urls import url
from query.views import zillow_query


urlpatterns = [
    url(
        r'^zillow$',
        zillow_query
    )
]
