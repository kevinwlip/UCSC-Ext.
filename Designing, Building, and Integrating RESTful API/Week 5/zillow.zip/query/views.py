import requests
import xml.etree.ElementTree as ET
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from rest_framework import status
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt


class JSONResponse(HttpResponse):
    def __init__(self, data, **headers):
        content = JSONRenderer().render(data)
        headers['content_type'] = 'application/json';
        super(JSONResponse, self).__init__(content, **headers)


@csrf_exempt
def zillow_query(request):
    if request.method == 'POST':
        query = JSONParser().parse(request)
        zillowid = 'X1-ZWz1hfkm8cs1zf_aj9j5'
        address = query['address']
        citystatezip = query['citystatezip']

        url = 'https://www.zillow.com/webservice/GetSearchResults.htm?zws-id={}&address={}&citystatezip={}'.format(
            zillowid, address, citystatezip)
        resp = requests.get(url=url)

        root = ET.fromstring(resp.text)

        if root.find('./response') is None:
            response = {'nomatch': True}
        else:
            amount = root.find('./response/results/result/zestimate/amount')
            link = root.find('./response/results/result/links/homedetails')

            response = {'nomatch': False, 'amount': int(amount.text), 'link': link.text}

        return JSONResponse(
            response,
            status=status.HTTP_200_OK
        )
