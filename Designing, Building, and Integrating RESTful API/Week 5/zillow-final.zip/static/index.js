$(() => {
    const query = () => {
        const address = $('#address').val();
        const citystate = $('#citystate').val();

        $.ajax({
            url: '/api/zillow',
            type: 'POST',
            data: JSON.stringify({
                address: address,
                citystate: citystate
            }),
            contentType: 'application/json',
            dataType: 'json',
            success: processZillow
        });
    }

    const processZillow = response => {
        console.log(response);
        $('#address').val('');
        $('#citystate').val('');

        const amount = response.amount;
        const link = response.link;
        $('#zillow-info').html(
            `
                <div>
                    <h5>Amount: \$${amount.toLocaleString('en-US')}</h5>
                    <div><a href="${link}" target="_blank">Open Zillow Page</a></div>
                </div>
            `
        )
    }

    $('#query-btn').on('click', () => query());
})