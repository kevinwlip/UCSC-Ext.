from django.conf.urls import url, include
from django.urls import path
from query.web_views import index

urlpatterns = [
    url(
        r'^api/',
        include('query.urls')
    ),
    path('', index)
]
