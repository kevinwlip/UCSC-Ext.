from django.conf.urls import url
from accounts.views import AccountCollection, AccountItem


urlpatterns = [
    url(
        r'accounts$',
        AccountCollection.as_view()
    ),
    url(
        r'accounts/(?P<pk>[0-9]+)$',
        AccountItem.as_view()
    )
]
