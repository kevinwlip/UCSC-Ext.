from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Book(models.Model):
    TYPE_CHOICES = (
        ('KD', 'Kindle'),
        ('PB', 'Paperback'),
        ('HC', 'Hardcover')
    )

    title = models.CharField(max_length=50, unique=True)
    price = models.FloatField(default=0)
    description = models.CharField(max_length=250, blank=True)
    book_type = models.CharField(
        max_length=2,
        choices=TYPE_CHOICES,
        default='PB'
    )

    def __str__(self):
        return '{}: {} ({}) - {}'.format(
            self.id,
            self.title,
            self.price,
            self.get_book_type_display()
        )


class Comment(models.Model):
    content = models.CharField(max_length=250)
    comment_date = models.DateField()
    comment_user = models.CharField(max_length=50, blank=True)

    book = models.ForeignKey(
        Book,
        related_name='comments',
        on_delete=models.CASCADE
    )

    def __str__(self):
        return '{} @ {} by {}'.format(
            self.content,
            self.comment_date,
            self.comment_user
        )


class Rate(models.Model):
    value = models.IntegerField(validators=[
        MinValueValidator(1),
        MaxValueValidator(5)
    ])

    book = models.ForeignKey(
        Book,
        related_name='ratings',
        on_delete=models.CASCADE
    )
