from django.conf.urls import url
from books.views import BookCollection, BookItem, CommentCollection, CommentItem, RateCollection

urlpatterns = [
    url(
        r'books$',
        BookCollection.as_view(),
        name='book-collection'
    ),
    url(
        r'books/(?P<pk>[0-9]+)$',
        BookItem.as_view(),
        name='book-item'
    ),
    url(
        r'comments$',
        CommentCollection.as_view(),
        name='comment-collection'
    ),
    url(
        r'comments/(?P<pk>[0-9]+)$',
        CommentItem.as_view(),
        name='comment-item'
    ),
    url(
        r'rates$',
        RateCollection.as_view()
    ),
]