from rest_framework import generics
from books.models import Book, Comment, Rate
from books.serializers import BookSerializer, CommentSerializer, RateSerializer


class BookCollection(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


class BookItem(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


class CommentCollection(generics.CreateAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class CommentItem(generics.RetrieveAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class RateCollection(generics.CreateAPIView):
    queryset = Rate.objects.all()
    serializer_class = RateSerializer
