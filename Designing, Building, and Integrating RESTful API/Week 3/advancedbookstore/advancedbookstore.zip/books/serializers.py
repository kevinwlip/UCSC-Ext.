from rest_framework import serializers
from django.db.models import Avg
from books.models import Book, Comment, Rate


class CommentSerializer(serializers.ModelSerializer):
    book_title = serializers.SerializerMethodField()

    def get_book_title(self, instance):
        return instance.book.title

    class Meta:
        model = Comment
        fields = '__all__'
        extra_kwargs = {
            'book': {'write_only': True}
        }


class RateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rate
        fields = '__all__'


class BookSerializer(serializers.ModelSerializer):
    # comments = serializers.HyperlinkedRelatedField(
    #     many=True,
    #     read_only=True,
    #     view_name='comment-item'
    # )

    comments = CommentSerializer(many=True, read_only=True)

    book_type_text = serializers.SerializerMethodField()

    def get_book_type_text(self, instance):
        return instance.get_book_type_display()

    popular = serializers.SerializerMethodField(
        method_name='is_popular'
    )

    def is_popular(self, instance):
        result = Rate.objects.filter(book=instance.pk).aggregate(
            Avg('value')
        )
        avg = result['value__avg']
        return avg is not None and avg >= 3

    class Meta:
        model = Book
        fields = '__all__'
        extra_kwargs = {
            'description': {'write_only': True},
            'book_type': {'write_only': True}
        }



