from django.conf.urls import url
from books.views import BookCollection, BookItem

urlpatterns = [
    url(
        r'books$',
        BookCollection.as_view()
    ),
    url(
        r'books/(?P<pk>[0-9]+)$',
        BookItem.as_view()
    )
]