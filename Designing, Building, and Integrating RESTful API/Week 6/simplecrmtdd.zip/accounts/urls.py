from django.conf.urls import url
from accounts.views import AccountList


urlpatterns = [
    url(
        r'^accounts$',
        AccountList.as_view(),
        name=AccountList.name
    )
]