from rest_framework import generics, permissions
from accounts.models import Account
from accounts.serializers import AccountSerializer


class AccountList(generics.ListCreateAPIView):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer
    name = 'account-list'

    search_fields = ('industry', )
    ordering_fields = ('name', )

    permission_classes = (
        permissions.IsAuthenticatedOrReadOnly,
    )

