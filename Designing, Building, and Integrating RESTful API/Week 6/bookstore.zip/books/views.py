from rest_framework import generics
from django_filters import FilterSet, NumberFilter
from books.models import Book
from books.serializers import BookSerializer


class PriceFilter(FilterSet):
    highest_price = NumberFilter(
        field_name='price',
        lookup_expr='lte'
    )

    lowest_price = NumberFilter(
        field_name='price',
        lookup_expr='gte'
    )

    class Meta:
        models = Book
        fields = ('price', )


class BookCollection(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

    search_fields = ('^title', '=book_type')
    # limit the sortable fields
    ordering_fields = ('price', 'title')

    filter_class = PriceFilter
