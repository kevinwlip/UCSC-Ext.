PEW RESEARCH CENTER
Wave 63 American Trends Panel 
Dates: March 2 - March 15, 2020
Mode: Web
Sample: ATP subsample with KnowledgePanel oversample
Language: English and Spanish
N=3,640

***************************************************************************************************************************
NOTE

Variable XPANEL_W63 identifies if the sample is from KnowledgePanel (XPANEL_W63=1) or ATP (XPANEL_W63=2).

***************************************************************************************************************************
WEIGHTS 


WEIGHT_W63 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.

***************************************************************************************************************************
Releases from this survey:

July 28, 2020 "Parenting Children in the Age of Screens"
https://www.pewresearch.org/internet/2020/07/28/parenting-children-in-the-age-of-screens/


